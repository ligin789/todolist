import { Link } from "react-router-dom";
import './Navbar.css'
import { useState } from "react";

const Navbar=(props:any)=> {

    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const handleMenuToggle = () => {
      setIsMenuOpen(prevState => !prevState);
    };

  return (
    <nav className="headerNav">
      <div className="Headercontainer">
        <div className="logo">
          <Link className="link" to="/">Your Logo</Link>
        </div>
        <div id="mainListDiv" className={`main_list ${isMenuOpen ? 'show_list' : ''}`}>
        <ul className="navlinks">
          <li><Link className="link" to="/">Home</Link></li>
          <li><Link className="link" to="/menu">Menu</Link></li>
          <li><Link className="link" to="/favorites">My Favourites</Link></li>
          <li> <Link className="link" to="/random">Meal Generator</Link></li>
          <li> <Link className="link" to="/about">About Me</Link></li>
          </ul>
        </div>
        <span className={`navTrigger ${isMenuOpen ? 'active' : ''}`} onClick={handleMenuToggle}>
                <i></i>
                <i></i>
                <i></i>
            </span>
      </div>
    </nav>
  );
}

export default Navbar;

