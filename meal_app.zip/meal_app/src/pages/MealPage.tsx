import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import MealCard from '../components/MealCard';

function MealsPage() {
  const { category } = useParams();
  const [meals, setMeals] = useState([]);

  useEffect(() => {
    axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${category}`)
      .then(response => setMeals(response.data.meals));
  }, [category]);

  return (
    <div>
      <h1>{category} Meals</h1>
      <div>
        {meals.map(meal => (
          <MealCard key={meal.idMeal} meal={meal} />
        ))}
      </div>
    </div>
  );
}

export default MealsPage;
