import { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function MenuPage() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    axios
      .get("https://www.themealdb.com/api/json/v1/1/categories.php")
      .then((response) => setCategories(response.data.categories));
  }, []);

  return (
    <div>
      <h2>All category</h2>
      <ul
       className="d-flex jus"
      >
        {categories.map((category) => (
          <div
            className="card m-3"
            key={category.idCategory}
            style={{ width: "18rem" }}
          >
            <img
              className="card-img-top"
              src={category?.strCategoryThumb}
              alt="Card image cap"
            />
            <div className="card-body">
              <h5 className="card-title">{category?.strCategory}</h5>
            </div>
          </div>
        ))}
      </ul>
    </div>
  );
}

export default MenuPage;
