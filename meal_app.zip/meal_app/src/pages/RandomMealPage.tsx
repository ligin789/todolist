import { useState, useEffect } from 'react';
import axios from 'axios';

function RandomMealPage() {
  const [meal, setMeal] = useState(null);

  const fetchRandomMeal = () => {
    axios.get('https://www.themealdb.com/api/json/v1/1/random.php')
      .then(response => setMeal(response.data.meals[0]));
  };

  useEffect(() => {
    fetchRandomMeal();
  }, []);

  return (
    <div>
      <h1>Random Meal Generator</h1>
      {meal && (
        <div>
          <img src={meal.strMealThumb} alt={meal.strMeal} />
          <h2>{meal.strMeal}</h2>
          <button onClick={() => {/* Add to favorites */}}>Add to Favorites</button>
          <button onClick={fetchRandomMeal}>Get Another Meal</button>
        </div>
      )}
    </div>
  );
}

export default RandomMealPage;
