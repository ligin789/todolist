function HomePage() {
    return (
      <div>
        <h1>Welcome to the Meal App</h1>
        <p>Choose an option from the menu</p>
      </div>
    );
  }
  
  export default HomePage;
  