function AboutPage() {
    return (
      <div>
        <h1>About Me</h1>
        <p>Personal information and comments go here.</p>
      </div>
    );
  }
  
  export default AboutPage;
  