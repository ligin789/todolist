import { useState, useEffect } from 'react';

function FavoritesPage() {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    // Load favorites from local storage or backend here
  }, []);

  const handleRemove = (id) => {
    // Remove from favorites and update state here
  };

  return (
    <div>
      <h1>My Favorites</h1>
      <div>
        {favorites.map(meal => (
          <div key={meal.idMeal}>
            <img src={meal.strMealThumb} alt={meal.strMeal} />
            <h2>{meal.strMeal}</h2>
            <button onClick={() => handleRemove(meal.idMeal)}>Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FavoritesPage;
